<?php
  header("Content-Type: application/json");

  $request = json_decode(file_get_contents('php://input'), true);
  $email = $request['email'];
  $password = $request['password'];

  if ($email == "admin" && $password == "ramirez") {
    http_response_code(200);
    echo json_encode(array("message" => "Success! Here is your flag TCM{bb0071bbbe798d0791e1812aafa8e384}"));
  } elseif ($email == "jeremy" && $password == "07061955") {
    http_response_code(200);
    echo json_encode(array("message" => "Success! Here is your flag TCM{342e20f13b1739db6d10750ca6b9cdaf}"));
  }  elseif ($email != "admin" && $email != "jeremy") {
    http_response_code(401);
    echo json_encode(array("message" => "Invalid username"));
  } else {
    http_response_code(401);
    echo json_encode(array("message" => "Invalid password!"));
  }
