<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Brute force demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    
  <main>
  <div class="container py-4">
    <header class="pb-3 mb-4 border-bottom">
      <a href="index.php" class="d-flex align-items-center text-dark text-decoration-none">
        <span class="fs-4">Why not brew a coffee while you wait...</span>
      </a>
    </header>

    <div class="p-5 mb-4 bg-dark text-light rounded-3">
      <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Brute-force me</h1>
        <p class="col-md-8 fs-4">Try using tools such as hydra, burp suite, or maybe build something yourself with python...</p>
        
        <!-- start modal -->
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#orderModal">
            Login
            </button>
            <!-- Modal -->
            <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderCoffeeLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5 text-dark" id="orderCoffeeLabel">Login</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="modal-order">
                    <!-- form -->
                    <div class="form-group">
                        <label for="inputEmail1">Username</label>
                        <input type="email" class="form-control" id="inputEmail1" aria-describedby="emailHelp" placeholder="Enter username">
                    </div>
                    <div class="form-group" style="margin-top: 10px">
                        <label for="inputPassword1">Password</label>
                        <input type="password" class="form-control" id="inputPassword1" aria-describedby="emailHelp" placeholder="Enter password">
                    </div>

                    <hr>
                    <div style="clear: both"></div>
                    <button type="submit" class="btn btn-primary" onclick="login()">Login</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <!-- end form -->
                </div>
            </div>
            </div>
            </div>
            <!-- end modal -->

      </div>
    </div>


    <footer class="pt-3 mt-4 text-muted border-top">
      &copy; 2022
    </footer>
  </div>
</main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script>
        // login
        const login = async () => {
        let formEmail = document.getElementById('inputEmail1').value;
        let formPassword = document.getElementById("inputPassword1").value;
        console.log(formEmail);
        console.log(formPassword);
        let uri = 'v1/verify.php';
        const response = await fetch(uri, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ email: formEmail, password: formPassword })
        });
            const loginStatus = await response.json();
            alert(loginStatus.message);
        }

    </script>
  </body>
</html>
