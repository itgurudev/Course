const express = require("express");
const jwt = require("jsonwebtoken");
const SECRET = "ucyxu6";

const app = express();
app.use(express.json());

app.post("/login", (req, res) => {
  // curl -X POST http://localhost/login --header "Content-Type: application/json" --data '{ "username": "admin", "password": "admin" }'
  const { username, password } = req.body;

  if (username === "user" && password === "user") {
    return res.json({
      token: jwt.sign({ userid: "user" }, SECRET),
    });
  }

  if (username === "admin" && password === "admin") {
    return res.json({
      token: jwt.sign({ userid: "admin" }, SECRET),
    });
  }

  return res
    .status(401)
    .json({message: "The username and password you provided are invalid"});
});

app.get("/dashboard", (req, res) => {
  // curl -i localhost/dashboard --Header 'Authorization: Bearer JWT'
  const token = req.headers.authorization.split(' ')[1];
  if(!token) return res.status(401).json('Unauthorized');
  try {
    const decoded = jwt.verify(token, SECRET);
    //const decoded = jwt.decode(token, SECRET);
    req.user = decoded;
  } catch(e) {
    res.status(400).json(e);
  }
  
  return res
    .status(200)
    .json({message: `Welcome to your dashboard ${req.user.userid}`});
});

app.listen(80, () => {
  console.log("http://localhost:80");
});
